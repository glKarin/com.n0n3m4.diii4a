#include "RenderThread.h"

#define RENDER_THREAD_STARTED() (Sys_ThreadIsRunning(&render_thread))
#define RENDER_SUB_THREAD_STARTED() (Sys_ThreadIsRunning(&sub_render_thread))

void GLimp_ActivateSharedContext();
void GLimp_DeactivateSharedContext();
void GLimp_CreateSharedContext(void);
void GLimp_DestroySharedContext(void);

bool multithreadActive = false;
bool multithreadEnable = false;

static idRenderThread renderThreadInstance;
idRenderThread *renderThread = &renderThreadInstance;

static idCVar r_multithread("r_multithread",
#if defined(__ANDROID__) || defined(ID_DEDICATED)
        "0"
#else
        "1"
#endif
        , CVAR_ARCHIVE | CVAR_INIT | CVAR_BOOL | CVAR_RENDERER, "Multithread backend. Allow using command `multithread` to enable or disable if `r_multithread` is 1");

static void * BackendThread(void *data)
{
    renderThreadInstance.render_thread_finished = false;
    Sys_Printf("[RenderThread]: Enter " GAME_NAME " render thread -> %s\n", Sys_GetThreadName());
    GLimp_ActivateContext();
    while(true)
    {
        renderThreadInstance.BackendThreadTask();
        if(THREAD_CANCELED(renderThreadInstance.render_thread) || renderThreadInstance.backendThreadShutdown)
            break;
    }
    GLimp_DeactivateContext();
    Sys_Printf("[RenderThread]: Leave " GAME_NAME " render thread -> %s\n", RENDER_THREAD_NAME);
    renderThreadInstance.render_thread_finished = true;
    Sys_TriggerEvent(TRIGGER_EVENT_RENDER_THREAD_FINISHED);
    return NULL;
}

static void * BackendThread_sub(void *data)
{
    renderThreadInstance.sub_render_thread_finished = false;
    Sys_Printf("[RenderThread]: Enter " GAME_NAME " render sub thread -> %s\n", Sys_GetThreadName());
    GLimp_ActivateSharedContext();
    while(true)
    {
        renderThreadInstance.BackendThreadUploadTask();
        if(THREAD_CANCELED(renderThreadInstance.sub_render_thread) || renderThreadInstance.sub_backendThreadShutdown)
            break;
    }
    GLimp_DeactivateSharedContext();
    Sys_Printf("[RenderThread]: Leave " GAME_NAME " render sub thread -> %s\n", RENDER_THREAD_NAME);
    renderThreadInstance.sub_render_thread_finished = true;
    Sys_TriggerEvent(TRIGGER_EVENT_RENDER_THREAD_FINISHED2);
    return NULL;
}

idRenderThread::idRenderThread()
: backendThreadShutdown(false),
  render_thread_finished(false),
  backendFinished(true),
  vertListToRender(0),
  sub_backendThreadShutdown(false),
  sub_render_thread_finished(false),
  sub_backendFinished(true),
  sub_vertListToRender(0),
  fdToRender(NULL),
  pixelsCrop(NULL),
  pixels(NULL),
  requestState(REQ_NONE)
{
    memset(&render_thread, 0, sizeof(render_thread));
    memset(&sub_render_thread, 0, sizeof(sub_render_thread));
    memset(&syncs[0], 0, sizeof(syncs));
//    imagesAlloc.Resize( 1024, 1024 );
//    imagesPurge.Resize( 1024, 1024 );
#ifdef _QUEUE_LIST_RECYCLE
	imagesAlloc.SetRecycle(true);
	imagesPurge.SetRecycle(true);
	for(int i = 0; i < NUM_FRAME_DATA; i++)
		bufferBlocks[i].SetRecycle(true);
#endif
}

void idRenderThread::BackendThreadExecute( void )
{
    if(!multithreadActive)
        return;
    if (RENDER_THREAD_STARTED())
        return;
    GLimp_DeactivateContext();
    backendThreadShutdown = false;
    Sys_CreateThread(BackendThread, common, THREAD_HIGHEST, render_thread, RENDER_THREAD_NAME, g_threads, &g_thread_count);
    common->Printf("[MainThread]: Render thread start -> %zu(%s)\n", XTHREAD_ID(render_thread), RENDER_THREAD_NAME);
}

void idRenderThread::BackendThreadShutdown( void )
{
    if(!multithreadActive)
        return;
    if (!RENDER_THREAD_STARTED())
        return;
    BackendThreadWait();
    backendThreadShutdown = true;
    Sys_TriggerEvent(TRIGGER_EVENT_RUN_BACKEND);
	xthreadHandle_t threadId = XTHREAD_ID(render_thread);
    Sys_DestroyThread(render_thread);
	render_thread.name = "";
    while(!render_thread_finished)
        Sys_WaitForEvent(TRIGGER_EVENT_RENDER_THREAD_FINISHED);
    GLimp_ActivateContext();
    common->Printf("[MainThread]: Render thread shutdown -> %zu(%s)\n", threadId, RENDER_THREAD_NAME);
}

// only render thread is running and main thread is waiting
ID_INLINE static void RB_OnlyRenderThreadRunningAndMainThreadWaiting(void)
{
    // Load custom GLSL shader or reload GLSL shaders
    RB_GLSL_HandleShaders();
    // debug tools
    RB_SetupRenderTools();
//#ifdef _IMGUI
    // start imgui
    //RB_ImGui_Start();
//#endif
}


void idRenderThread::BackendThreadTask( void ) // BackendThread ->
{
    HARM_MT_DEBUG("Render wait RUN_BACKEND: %d\n", vertListToRender);
    // waiting start
    Sys_WaitForEvent(TRIGGER_EVENT_RUN_BACKEND);

    // Purge all images,  Load all images
    this->HandlePendingImage();

    // main thread is waiting render thread, only render thread is running
    RB_OnlyRenderThreadRunningAndMainThreadWaiting();

    // image process finished
    Sys_TriggerEvent(TRIGGER_EVENT_IMAGES_PROCESSES);

    int backendVertexCache = vertListToRender;

    HARM_MT_DEBUG("Render working: %d\n", backendVertexCache);
    vertexCache.BeginBackEnd(backendVertexCache);
    R_IssueRenderCommands(fdToRender);

    // Take screen shot
    if(pixels) // if block backend rendering, do not exit backend render function, because it will be swap buffers in GLSurfaceView
    {
        qglReadPixels( pixelsCrop->x, pixelsCrop->y, pixelsCrop->width, pixelsCrop->height, GL_RGBA, GL_UNSIGNED_BYTE, (void*)pixels );
        pixels = NULL;
        pixelsCrop = NULL;
    }

    vertexCache.EndBackEnd(backendVertexCache);
    HARM_MT_DEBUG("Render finished: %d\n", backendVertexCache);
    backendFinished = true;
    HARM_MT_DEBUG("Render trigger BACKEND_FINISHED: %d\n", backendVertexCache);
    Sys_TriggerEvent(TRIGGER_EVENT_BACKEND_FINISHED);
    HARM_MT_DEBUG("Render goto next: %d\n", backendVertexCache);
}

void idRenderThread::BackendThreadSingleTask( void ) // SingleThread ->
{
    // Purge all images,  Load all images
    this->HandlePendingImage();

    // main thread is waiting render thread, only render thread is running
    RB_OnlyRenderThreadRunningAndMainThreadWaiting();

    int backendVertexCache = vertListToRender;
    vertexCache.BeginBackEnd(backendVertexCache);
    R_IssueRenderCommands(fdToRender);

    // Take screen shot
    if(pixels) // if block backend rendering, do not exit backend render function, because it will be swap buffers in GLSurfaceView
    {
        qglReadPixels( pixelsCrop->x, pixelsCrop->y, pixelsCrop->width, pixelsCrop->height, GL_RGBA, GL_UNSIGNED_BYTE, (void*)pixels );
        pixels = NULL;
        pixelsCrop = NULL;
    }

    vertexCache.EndBackEnd(backendVertexCache);
    backendFinished = true;
}

void idRenderThread::BackendThreadToolsTask( void ) // SingleThread for tools ->
{
    // Purge all images,  Load all images
    this->HandlePendingImage();

    // main thread is waiting render thread, only render thread is running
    // RB_OnlyRenderThreadRunningAndMainThreadWaiting();
}

// waiting backend render finished
void idRenderThread::BackendThreadWait( void )
{
    while(/*multithreadActive &&*/ !backendFinished)
    {
        //usleep(1000 * 3);
        Sys_WaitForEvent(TRIGGER_EVENT_BACKEND_FINISHED);
        //usleep(500);
    }
}

bool idRenderThread::IsActive( void ) const
{
    return multithreadActive && Sys_ThreadIsRunning(&render_thread);
}

#if 1
#define HARM_MT_IMAGES_DEBUG(...)
#else
#define HARM_MT_IMAGES_DEBUG(...) printf("[MT]: " __VA_ARGS__)
#endif
void idRenderThread::AddAllocList( idImage * image, bool checkForPrecompressed, bool fromBackEnd )
{
    // Front and backend threads can add images, protect this
    Sys_EnterCriticalSection( CRITICAL_SECTION_TWO );

    if(image)
    {
        HARM_MT_IMAGES_DEBUG("AddAllocList::before num = %d\n", imagesAlloc.Num());
        imagesAlloc.Append( ActuallyLoadImage_data_t( image, checkForPrecompressed, fromBackEnd ) );
        HARM_MT_IMAGES_DEBUG("AddAllocList::after num = %d\n", imagesAlloc.Num());
    }

    Sys_LeaveCriticalSection( CRITICAL_SECTION_TWO );
}

void idRenderThread::AddPurgeList( idImage * image )
{
    if(image)
    {
        HARM_MT_IMAGES_DEBUG("AddPurgeList::before num = %d\n", imagesPurge.Num());
        imagesPurge.Append( image );
        HARM_MT_IMAGES_DEBUG("AddPurgeList::after num = %d\n", imagesPurge.Num());
        image->purgePending = true;
    }
}

bool idRenderThread::GetNextAllocImage( ActuallyLoadImage_data_t &img )
{
    HARM_MT_IMAGES_DEBUG("GetNextAllocImage::not empty = %d\n", imagesAlloc.NotEmpty());
    if(imagesAlloc.NotEmpty())
    {
        HARM_MT_IMAGES_DEBUG("GetNextAllocImage::before remove num = %d\n", imagesAlloc.Num());
        const ActuallyLoadImage_data_t &ref = imagesAlloc.Get();
        img.image = ref.image;
        img.checkForPrecompressed = ref.checkForPrecompressed;
        img.fromBackEnd = ref.fromBackEnd;
        imagesAlloc.Remove();
        HARM_MT_IMAGES_DEBUG("GetNextAllocImage::after remove num = %d\n", imagesAlloc.Num());
        return true;
    }

    return false;
}

idImage * idRenderThread::GetNextPurgeImage( void )
{
    idImage * img = NULL;

    HARM_MT_IMAGES_DEBUG("GetNextPurgeImage::not empty = %d\n", imagesPurge.NotEmpty());
    if(imagesPurge.NotEmpty())
    {
        HARM_MT_IMAGES_DEBUG("GetNextPurgeImage::before remove num = %d\n", imagesPurge.Num());
        img = imagesPurge.Get();
        imagesPurge.Remove();
        img->purgePending = false;
        HARM_MT_IMAGES_DEBUG("GetNextPurgeImage::after remove num = %d\n", imagesPurge.Num());
    }

    return img;
}

void idRenderThread::HandlePendingImage( void )
{
    // Purge all images
    idImage * img;
    while( (img = GetNextPurgeImage()) != NULL )
    {
        img->PurgeImage();
    }

    // Load all images
    ActuallyLoadImage_data_t imgData;
    while(GetNextAllocImage(imgData))
    {
        imgData.image->ActuallyLoadImage( imgData.checkForPrecompressed, false ); // false
    }
}

void idRenderThread::ClearImages( void )
{
#if 0
    imagesAlloc.Clear();
    imagesPurge.Clear();
#else
    HARM_MT_IMAGES_DEBUG("ClearImages::alloc list not empty = %d\n", imagesAlloc.NotEmpty());
    while(imagesAlloc.NotEmpty())
    {
        HARM_MT_IMAGES_DEBUG("ClearImages::alloc list before remove num = %d\n", imagesAlloc.Num());
        imagesAlloc.Remove();
        HARM_MT_IMAGES_DEBUG("ClearImages::alloc list after remove num = %d\n", imagesAlloc.Num());
    }

    HARM_MT_IMAGES_DEBUG("ClearImages::purge list not empty = %d\n", imagesPurge.NotEmpty());
    while(imagesPurge.NotEmpty())
    {
        HARM_MT_IMAGES_DEBUG("ClearImages::purge list before remove num = %d\n", imagesPurge.Num());
        imagesPurge.Remove();
        HARM_MT_IMAGES_DEBUG("ClearImages::purge list after remove num = %d\n", imagesPurge.Num());
    }
#endif
}

void idRenderThread::Request( bool on )
{
    if(!multithreadActive)
        return;
	if(multithreadEnable == on)
		return;
	if(requestState != REQ_NONE)
	{
		common->Printf("Render thread has been request change to %s.\n", requestState == REQ_ENABLE ? "enable" : "disable");
		return;
	}
	if(on)
	{
		requestState = REQ_ENABLE;
		common->Printf("Render thread will be change to enable.\n");
	}
	else
	{
		requestState = REQ_DISABLE;
		common->Printf("Render thread will be change to disable.\n");
	}
}

void idRenderThread::SyncState( void )
{
    if(!multithreadActive)
        return;
	if(requestState == REQ_NONE)
		return;
	bool on = requestState == REQ_ENABLE;
	if(multithreadEnable == on)
		return;

	requestState = REQ_NONE;
	multithreadEnable = on;
	common->Printf("Render thread request change to %s.\n", on ? "enable" : "disable");
	if(on)
	{
		BackendThreadExecute();
		common->Printf("Render thread change to enable.\n");
	}
	else
	{
		backendFinished = true;
        Sys_TriggerEvent(TRIGGER_EVENT_RUN_BACKEND);
		BackendThreadShutdown();
		backendFinished = false;
		common->Printf("Render thread change to disable.\n");
	}
}

bool Sys_InRenderThread(void)
{
    return Sys_InThread(&renderThreadInstance.render_thread);
}

void Sys_ShutdownRenderThread(void)
{
    if(multithreadActive)
    {
        Sys_TriggerEvent(TRIGGER_EVENT_RUN_BACKEND);
        renderThreadInstance.BackendThreadShutdown();
    }
}

void R_EnableRenderThread_f(const idCmdArgs &args)
{
	if(!multithreadActive)
	{
		common->Printf("Multi-threading is not active\n");
		return;
	}
	if(args.Argc() > 1)
	{
		const char *st = args.Argv(1);
		bool on = st && st[0] && idStr::Cmp("0", st);
		renderThreadInstance.Request(on);
	}
	else
	{
		renderThreadInstance.Request(!multithreadEnable);
	}
}

void RB_ToolsRenderTask(void)
{
    renderThreadInstance.BackendThreadToolsTask();
}

volatile int sub_vertListToRender2 = 1;
vertCache_t * idRenderThread::GetNextUploadBuffer( void )
{
    vertCache_t * buf = NULL;

	idQueueList<struct vertCache_s *> &blocks = bufferBlocks[sub_vertListToRender2];
    HARM_MT_IMAGES_DEBUG("GetNextUploadBuffer::not empty = %d\n", blocks.NotEmpty());
    if(blocks.NotEmpty())
    {
        HARM_MT_IMAGES_DEBUG("GetNextUploadBuffer::before remove num = %d\n", blocks.Num());
        buf = blocks.Get();
        blocks.Remove();
        HARM_MT_IMAGES_DEBUG("GetNextUploadBuffer::after remove num = %d\n", blocks.Num());
    }

    return buf;
}

void idRenderThread::HandleUploadBuffer( void )
{
	Sys_EnterCriticalSection(TRIGGER_EVENT_THREE);
	int old = sub_vertListToRender2;
	sub_vertListToRender2 = sub_vertListToRender;
	sub_vertListToRender = old;
	Sys_LeaveCriticalSection(TRIGGER_EVENT_THREE);

    // Upload buffer
    vertCache_t * buf;
    while( (buf = GetNextUploadBuffer()) != NULL )
    {
        vertexCache.Upload(buf);
    }
}

void idRenderThread::BackendThreadUploadTask( void )
{
    HARM_MT_DEBUG("Sub wait RUN_BACKEND2: %d\n", sub_vertListToRender);
    // waiting start
    Sys_WaitForEvent(TRIGGER_EVENT_RUN_BACKEND2);

    int sub_backendVertexCache = sub_vertListToRender;

    HARM_MT_DEBUG("Sub handle image: %d\n", sub_backendVertexCache);

    HARM_MT_DEBUG("Sub trigger IMAGES_PROCESSES2: %d\n", sub_backendVertexCache);
    Sys_TriggerEvent(TRIGGER_EVENT_IMAGES_PROCESSES2);

    HARM_MT_DEBUG("Sub working: %d\n", sub_backendVertexCache);

    // Purge all buffers
    HandleUploadBuffer();

    //vertexCache.EndBackEnd(sub_backendVertexCache);
    HARM_MT_DEBUG("Sub wait BACKEND_FINISHED: %d\n", sub_backendVertexCache);

    sub_backendFinished = true;
    HARM_MT_DEBUG("Sub trigger BACKEND_FINISHED2: %d\n", sub_backendVertexCache);
    Sys_TriggerEvent(TRIGGER_EVENT_BACKEND_FINISHED2);

    HARM_MT_DEBUG("Sub goto next: %d\n", sub_backendVertexCache);
}

void idRenderThread::BackendThreadUploadExecute( void )
{
    if(!multithreadActive)
        return;
    if (RENDER_SUB_THREAD_STARTED())
        return;
    //GLimp_DeactivateSharedContext();
    sub_backendThreadShutdown = false;
	GLimp_CreateSharedContext();
    Sys_CreateThread(BackendThread_sub, common, THREAD_HIGHEST, sub_render_thread, RENDER_SUB_THREAD_NAME, g_threads, &g_thread_count);
    common->Printf("[MainThread]: Render sub thread start -> %zu(%s)\n", XTHREAD_ID(sub_render_thread), RENDER_SUB_THREAD_NAME);
}

void idRenderThread::BackendThreadUploadWait( void )
{
    while(/*multithreadActive &&*/ !sub_backendFinished)
    {
        //usleep(1000 * 3);
        Sys_WaitForEvent(TRIGGER_EVENT_BACKEND_FINISHED2);
        //usleep(500);
    }
}

void idRenderThread::AddUploadList( struct vertCache_s * buf )
{
    if(buf)
    {
		Sys_EnterCriticalSection(TRIGGER_EVENT_THREE);
		idQueueList<struct vertCache_s *> &blocks = bufferBlocks[sub_vertListToRender];
        HARM_MT_IMAGES_DEBUG("AddUploadList::before num = %d\n", blocks.Num());
        blocks.Append( buf );
        HARM_MT_IMAGES_DEBUG("AddUploadList::after num = %d\n", blocks.Num());
		Sys_LeaveCriticalSection(TRIGGER_EVENT_THREE);
		renderThread->sub_backendFinished = false;
		Sys_TriggerEvent(TRIGGER_EVENT_RUN_BACKEND2);
    }
}

void idRenderThread::BackendThreadUploadShutdown( void )
{
    if(!multithreadActive)
        return;
    if (!RENDER_SUB_THREAD_STARTED())
        return;
    BackendThreadUploadWait();
    sub_backendThreadShutdown = true;
    Sys_TriggerEvent(TRIGGER_EVENT_RUN_BACKEND2);
    xthreadHandle_t threadId = XTHREAD_ID(sub_render_thread);
    Sys_DestroyThread(sub_render_thread);
    sub_render_thread.name = "";
    while(!sub_render_thread_finished)
        Sys_WaitForEvent(TRIGGER_EVENT_RENDER_THREAD_FINISHED2);
    //GLimp_ActivateContext();
	GLimp_DestroySharedContext();
    common->Printf("[MainThread]: Render sub thread shutdown -> %zu(%s)\n", threadId, RENDER_SUB_THREAD_NAME);
}
