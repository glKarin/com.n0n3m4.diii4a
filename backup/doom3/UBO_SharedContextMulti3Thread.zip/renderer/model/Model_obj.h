/*
===========================================================================

Doom 3 BFG Edition GPL Source Code
Copyright (C) 1993-2012 id Software LLC, a ZeniMax Media company.
Copyright (C) 2021 Robert Beckebans

This file is part of the Doom 3 BFG Edition GPL Source Code ("Doom 3 BFG Edition Source Code").

Doom 3 BFG Edition Source Code is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Doom 3 BFG Edition Source Code is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Doom 3 BFG Edition Source Code.  If not, see <http://www.gnu.org/licenses/>.

In addition, the Doom 3 BFG Edition Source Code is also subject to certain additional terms. You should have received a copy of these additional terms immediately following the terms and conditions of the GNU General Public License which accompanied the Doom 3 BFG Edition Source Code.  If not, please request a copy in writing from id Software at the address below.

If you have questions concerning this license or the applicable additional terms, you may contact in writing id Software LLC, c/o ZeniMax Media Inc., Suite 120, Rockville, Maryland 20850 USA.

===========================================================================
*/

#ifndef __MODEL_OBJ_H__
#define __MODEL_OBJ_H__

/*
===============================================================================

	Wavefront OBJ loader.
	This is meant to be a very simple model format and we don't even care for .mtl files
	because we want all material properties to be defined through the D3 material system

===============================================================================
*/

struct objObject_t
{
	idStr						material;

	idList<idVec3>				vertexes;
	idList<idVec2>				texcoords;
	idList<idVec3>				normals;
	idList<glIndex_t>			indexes;
};

struct objModel_t
{
	ID_TIME_T							timeStamp;
	idList<objObject_t*>				objects;
};


objModel_t* OBJ_Load( const char* fileName );
void		OBJ_Free( objModel_t* obj );
void        OBJ_Write( const objModel_t* obj, const char* fileName );

#endif /* !__MODEL_OBJ_H__ */
