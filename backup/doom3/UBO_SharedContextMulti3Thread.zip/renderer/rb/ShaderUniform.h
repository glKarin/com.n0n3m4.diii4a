#ifndef _KARIN_SHADER_UNIFORM_H
#define _KARIN_SHADER_UNIFORM_H

class idUBO
{
public:
    explicit idUBO(void);
    ~idUBO(void);
    void Uniform1fv(GLint location, const GLfloat *value);
    void Uniform2fv(GLint location, const GLfloat *value);
    void Uniform3fv(GLint location, const GLfloat *value);
    void Uniform4fv(GLint location, const GLfloat *value);
    void Uniform1i(GLint location, GLint w);
    void Uniform4f(GLint location, GLfloat x, GLfloat y, GLfloat z, GLfloat w);
    void UniformMatrix4fv(GLint location, const GLfloat *value);
    void UniformMatrix4fv(GLint location, const GLsizei n, const GLfloat *value);
    void Uniform1f(GLint location, GLfloat value);

    // OpenGL thread
    void Init(GLuint program, GLint block, GLint bindingId);
    void Shutdown(void);
    void Commit(void);
    void Bind(void);
    void Unbind(void);
    static void UnbindAll(void);

    void Clear(void);
    void SetOffset(GLint location, GLint offset);

private:
    void UniformMem(GLint location, const GLfloat *data, int num);
    void InitBuffer(void);

public:
    GLint block;
    GLint binding;
    GLuint bufferId;

private:
    GLint size;
    GLint start;
    GLint end;
    byte *mem;
    shaderProgram_t layout;

    static GLuint currentBufferId;
};

ID_INLINE void idUBO::Uniform1fv(GLint location, const GLfloat *value) {
    UniformMem(location, value, 1);
}

ID_INLINE void idUBO::Uniform2fv(GLint location, const GLfloat *value) {
    UniformMem(location, value, 2);
}

ID_INLINE void idUBO::Uniform3fv(GLint location, const GLfloat *value) {
    UniformMem(location, value, 3);
}

ID_INLINE void idUBO::Uniform4fv(GLint location, const GLfloat *value) {
    UniformMem(location, value, 4);
}

ID_INLINE void idUBO::Uniform1i(GLint location, GLint w) {
    UniformMem(location, (const GLfloat *)&w, 1);
}

ID_INLINE void idUBO::Uniform4f(GLint location, GLfloat x, GLfloat y, GLfloat z, GLfloat w) {
    GLfloat v[] = {x, y, z, w};
    UniformMem(location, v, 4);
}

ID_INLINE void idUBO::UniformMatrix4fv(GLint location, const GLfloat *value) {
    UniformMem(location, value, 16);
}

ID_INLINE void idUBO::UniformMatrix4fv(GLint location, const GLsizei n, const GLfloat *value) {
    UniformMem(location, value, 16 * n);
}

ID_INLINE void idUBO::Uniform1f(GLint location, GLfloat value) {
    UniformMem(location, &value, 1);
}

ID_INLINE void idUBO::Bind(void)
{
    if(bufferId != currentBufferId)
    {
        qglBindBuffer(GL_UNIFORM_BUFFER, bufferId);
        currentBufferId = bufferId;
    }
}

ID_INLINE void idUBO::Unbind(void)
{
    if(bufferId == currentBufferId)
    {
        UnbindAll();
    }
}

ID_INLINE void idUBO::UnbindAll(void)
{
    qglBindBuffer(GL_UNIFORM_BUFFER, 0);
    currentBufferId = 0;
}

ID_INLINE void idUBO::UniformMem(GLint location, const GLfloat *data, int num)
{
    location = (*(GLint *)((char *)&layout + location));
    // if(location < 0) return;
    if(location < start)
        start = location;
    int len = num * 4;
    int endPos = location + len;
    if(endPos > end)
        end = endPos;
    memcpy(mem + location, data, len);
}

ID_INLINE void idUBO::Commit(void)
{
    if(start < end)
    {
        Bind();
        qglBufferSubData(GL_UNIFORM_BUFFER, start, end - start, mem);
        //Unbind();
        start = INT_MAX;
        end = INT_MIN;
    }
}

#endif /* !_KARIN_SHADER_UNIFORM_H */
