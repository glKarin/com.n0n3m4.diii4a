#include "../../idlib/precompiled.h"
#pragma hdrstop

#include "../tr_local.h"

GLuint idUBO::currentBufferId = 0;

idUBO::idUBO(void)
: mem(NULL)
{
    Clear();
}

idUBO::~idUBO(void)
{
    free(mem);
}

void idUBO::Clear(void)
{
    block = -1;
    binding = -1;
    size = 0;
    bufferId = 0;
    start = INT_MAX;
    end = INT_MIN;
    if(mem)
    {
        free(mem);
    }
    mem = NULL;
    memset(&layout, 0, sizeof(layout));
}

void idUBO::Init(GLuint program, GLint blockId, GLint bindingId)
{
    block = blockId;
    qglUniformBlockBinding(program, blockId, bindingId);
    binding = bindingId;
    qglGetActiveUniformBlockiv(program, block, GL_UNIFORM_BLOCK_DATA_SIZE, &size);
    InitBuffer();
}

void idUBO::Shutdown(void)
{
    if(bufferId > 0)
    {
        Unbind();
        qglDeleteBuffers(1, &bufferId);
        bufferId = 0;
    }
    Clear();
}

void idUBO::InitBuffer(void)
{
    int len = size / 4;
    if(size % 4)
        len++;
    mem = (byte *)malloc(len * 4);

    qglGenBuffers(1, &bufferId);
    Bind();
    qglBufferData(GL_UNIFORM_BUFFER, size, NULL, GL_STREAM_DRAW);
    qglBindBufferBase(GL_UNIFORM_BUFFER, binding, bufferId);
    Unbind();
}

void idUBO::SetOffset(GLint location, GLint offset)
{
    (*(GLint *)((char *)&layout + location)) = offset;
}
