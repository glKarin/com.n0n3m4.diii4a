
#define MINIFLAC_READ_BUFFER_LENGTH 65535

static MINIFLAC_RESULT
dump_streaminfo(miniflac_t* decoder, membuffer_t* mem,
                uint32_t *sample_rate, uint8_t *channels, uint8_t *bps, uint64_t *total_samples
                ) {
    uint32_t used;
    uint8_t  temp8;
    uint16_t temp16;
    uint32_t temp32;
    uint64_t temp64;
    uint8_t md5[16];
    MINIFLAC_RESULT res;

    fprintf(stdout,"[streaminfo]\n");

    if((res = miniflac_streaminfo_min_block_size(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp16)) != MINIFLAC_OK) return res;
    mem->pos += used;
    mem->len -= used;
    fprintf(stdout,"  min_block_size: %u\n",temp16);

    if((res = miniflac_streaminfo_max_block_size(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp16)) != MINIFLAC_OK) return res;
    mem->pos += used;
    mem->len -= used;
    fprintf(stdout,"  max_block_size: %u\n",temp16);

    if((res = miniflac_streaminfo_min_frame_size(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp32)) != MINIFLAC_OK) return res;
    mem->pos += used;
    mem->len -= used;
    fprintf(stdout,"  min_frame_size: %u\n",temp16);

    if((res = miniflac_streaminfo_max_frame_size(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp32)) != MINIFLAC_OK) return res;
    mem->pos += used;
    mem->len -= used;
    fprintf(stdout,"  max_frame_size: %u\n",temp16);

    // miniflac_streaminfo_sample_rate return num frames, not samples of all channels
    if((res = miniflac_streaminfo_sample_rate(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp32)) != MINIFLAC_OK) return res;
    mem->pos += used;
    mem->len -= used;
    fprintf(stdout,"  sample_rate: %u\n",temp32);
    if(sample_rate) *sample_rate = temp32;

    if((res = miniflac_streaminfo_channels(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp8)) != MINIFLAC_OK) return res;
    mem->pos += used;
    mem->len -= used;
    fprintf(stdout,"  channels: %u\n",temp8);
    if(channels) *channels = temp8;

    if((res = miniflac_streaminfo_bps(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp8)) != MINIFLAC_OK) return res;
    mem->pos += used;
    mem->len -= used;
    fprintf(stdout,"  bps: %u\n",temp8);
    if(bps) *bps = temp8;

    if((res = miniflac_streaminfo_total_samples(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp64)) != MINIFLAC_OK) return res;
    mem->pos += used;
    mem->len -= used;
    fprintf(stdout,"  total_samples: %llu\n",(unsigned long long)temp64);
    if(total_samples) *total_samples = temp64;

    if((res = miniflac_streaminfo_md5_data(decoder,&mem->buffer[mem->pos],mem->len,&used,md5,16,NULL)) != MINIFLAC_OK) return res;
    mem->pos += used;
    mem->len -= used;
    fprintf(stdout,"  md5: %02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x\n",
            md5[ 0], md5[ 1], md5[ 2], md5[ 3],
            md5[ 4], md5[ 5], md5[ 6], md5[ 7],
            md5[ 8], md5[ 9], md5[10], md5[11],
            md5[12], md5[13], md5[14], md5[15]);

    return res;
}

typedef void (*packer)(uint8_t* b, int32_t* pcm[8], uint32_t channels, uint32_t frame_size, uint8_t shift);

static void uint8_packer(uint8_t *outSamples, int32_t* samples[8], uint32_t channels, uint32_t frame_size, uint8_t shift) {
    uint32_t i = 0;
    uint32_t j = 0;
    uint32_t usample;
    for(i=0;i<frame_size;i++) {
        for(j=0;j<channels;j++) {
            usample = (uint32_t)samples[j][i];
            usample <<= shift;
            outSamples[1 * ((i*channels) + j)] = (uint8_t)usample;
        }
    }
}

static void
pack_uint16le(uint8_t* output, uint16_t n) {
    output[0] = (uint8_t)(n & 0xFF);
    output[1] = (uint8_t)(n >> 8  );
}

static void
pack_int16le(uint8_t* output, int16_t n) {
    pack_uint16le(output,(uint16_t)n);
}

static void int16_packer(uint8_t *outSamples, int32_t* samples[8], uint32_t channels, uint32_t frame_size, uint8_t shift) {
    uint32_t i = 0;
    uint32_t j = 0;
    uint32_t usample;
    for(i=0;i<frame_size;i++) {
        for(j=0;j<channels;j++) {
            usample = (uint32_t)samples[j][i];
            usample <<= shift;
            pack_int16le(&outSamples[2 * ((i*channels) + j)],(int16_t)usample);
        }
    }
}

static const char* my_miniflac_strerror(int flacError)
{
    switch(flacError)
    {
#define ERRCASE(X) \
		case MINIFLAC_ ## X : return #X;
        ERRCASE( OGG_HEADER_NOTFLAC )
        ERRCASE( SUBFRAME_RESERVED_TYPE )
        ERRCASE( SUBFRAME_RESERVED_BIT )
        ERRCASE( STREAMMARKER_INVALID )
        ERRCASE( RESERVED_CODING_METHOD )
        ERRCASE( METADATA_TYPE_RESERVED )
        ERRCASE( METADATA_TYPE_INVALID )
        ERRCASE( FRAME_RESERVED_SAMPLE_SIZE )
        ERRCASE( FRAME_RESERVED_CHANNEL_ASSIGNMENT )
        ERRCASE( FRAME_INVALID_SAMPLE_SIZE )
        ERRCASE( FRAME_INVALID_SAMPLE_RATE )
        ERRCASE( FRAME_RESERVED_BLOCKSIZE )
        ERRCASE( FRAME_RESERVED_BIT2 )
        ERRCASE( FRAME_RESERVED_BIT1 )
        ERRCASE( FRAME_SYNCCODE_INVALID )
        ERRCASE( FRAME_CRC16_INVALID )
        ERRCASE( FRAME_CRC8_INVALID )
        ERRCASE( ERROR )
        ERRCASE( METADATA_END )
        ERRCASE( CONTINUE )

        default: return "No Error";
#undef ERRCASE
    }
    assert(0 && "unknown miniflac errorcode!");
    return "Unknown miniflac Error!";
}

#if 1
static void
dump_vorbis_comment(miniflac_t* decoder, membuffer_t* mem) {
    uint32_t used = 0;
    uint32_t temp32 = 0;
    unsigned int i = 0;
    char* string_buffer = NULL;
    uint32_t string_buffer_len = 0;
    MINIFLAC_RESULT res = MINIFLAC_OK;

    fprintf(stdout,"[vorbis_comment]\n");

    if(miniflac_vorbis_comment_vendor_length(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp32) != MINIFLAC_OK) abort();
    mem->len -= used;
    mem->pos += used;

    if(temp32 > string_buffer_len) {
        string_buffer = (char*)realloc(string_buffer,temp32+1);
        if(string_buffer == NULL) abort();
        string_buffer_len = temp32;
    }

    fprintf(stdout,"  vendor string=[%u]",temp32);
    if(miniflac_vorbis_comment_vendor_string(decoder,&mem->buffer[mem->pos],mem->len,&used,string_buffer,string_buffer_len+1,&temp32) != MINIFLAC_OK)
        abort();
    mem->len -= used;
    mem->pos += used;
    string_buffer[temp32] = '\0';
    fprintf(stdout,"%s\n",string_buffer);

    while( (res =miniflac_vorbis_comment_length(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp32)) == MINIFLAC_OK) {
        mem->len -= used;
        mem->pos += used;
        fprintf(stdout,"  comment[%u]=[%u]",i++,temp32);
        if(temp32 > string_buffer_len) {
            string_buffer = (char*)realloc(string_buffer,temp32+1);
            if(string_buffer == NULL) abort();
            string_buffer_len = temp32;
        }
        if(miniflac_vorbis_comment_string(decoder,&mem->buffer[mem->pos],mem->len,&used,string_buffer,string_buffer_len+1,&temp32) != MINIFLAC_OK)
            abort();
        mem->len -= used;
        mem->pos += used;
        string_buffer[temp32] = '\0';
        fprintf(stdout,"%s\n",string_buffer);
    }
    mem->len -= used;
    mem->pos += used;

    if(res != MINIFLAC_METADATA_END) abort();
    free(string_buffer);
    fflush(stdout);
}

static void
dump_picture(miniflac_t* decoder, membuffer_t* mem) {
    uint32_t used = 0;
    uint32_t temp32 = 0;
    char* string_buffer = NULL;
    uint32_t string_buffer_len = 0;

    fprintf(stdout,"[picture]\n");
    if(miniflac_picture_type(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp32) != MINIFLAC_OK) abort();
    mem->len -= used;
    mem->pos += used;
    fprintf(stdout,"  type=%u\n",temp32);

    if(miniflac_picture_mime_length(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp32) != MINIFLAC_OK) abort();
    mem->len -= used;
    mem->pos += used;
    fprintf(stdout,"  mime string=[%u]",temp32);
    if(temp32 > string_buffer_len) {
        string_buffer = (char*)realloc(string_buffer,temp32 + 1);
        if(string_buffer == NULL) abort();
        string_buffer_len = temp32;
    }
    if(miniflac_picture_mime_string(decoder,&mem->buffer[mem->pos],mem->len,&used,string_buffer,string_buffer_len+1,&temp32) != MINIFLAC_OK) abort();
    mem->len -= used;
    mem->pos += used;
    string_buffer[temp32] = '\0';
    fprintf(stdout,"%s\n",string_buffer);

    if(miniflac_picture_description_length(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp32) != MINIFLAC_OK) abort();
    mem->len -= used;
    mem->pos += used;
    fprintf(stdout,"  description string=[%u]",temp32);
    if(temp32 > string_buffer_len) {
        string_buffer = (char*)realloc(string_buffer,temp32 + 1);
        if(string_buffer == NULL) abort();
        string_buffer_len = temp32;
    }

    if(miniflac_picture_description_string(decoder,&mem->buffer[mem->pos],mem->len,&used,string_buffer,string_buffer_len+1,&temp32) != MINIFLAC_OK) abort();
    mem->len -= used;
    mem->pos += used;
    string_buffer[temp32] = '\0';
    fprintf(stdout,"%s\n",string_buffer);

    if(miniflac_picture_width(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp32) != MINIFLAC_OK) abort();
    mem->len -= used;
    mem->pos += used;
    fprintf(stdout,"  width=%u\n",temp32);

    if(miniflac_picture_height(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp32) != MINIFLAC_OK) abort();
    mem->len -= used;
    mem->pos += used;
    fprintf(stdout,"  height=%u\n",temp32);

    if(miniflac_picture_colordepth(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp32) != MINIFLAC_OK) abort();
    mem->len -= used;
    mem->pos += used;
    fprintf(stdout,"  colordepth=%u\n",temp32);

    if(miniflac_picture_totalcolors(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp32) != MINIFLAC_OK) abort();
    mem->len -= used;
    mem->pos += used;
    fprintf(stdout,"  totalcolors=%u\n",temp32);

    if(miniflac_picture_length(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp32) != MINIFLAC_OK) abort();
    mem->len -= used;
    mem->pos += used;
    fprintf(stdout,"  data=[%u bytes]\n",temp32);

    /* notice we skip grabbing the picture data - we can stop parsing a metadata
     * block whenever we like and call miniflac_sync to move ahead to the next
     * block boundary */
    free(string_buffer);
    fflush(stdout);
}

static void
dump_cuesheet(miniflac_t* decoder, membuffer_t* mem) {
    uint32_t used = 0;
    uint8_t  temp8 = 0;
    uint32_t temp32 = 0;
    uint64_t temp64 = 0;
    unsigned int i = 0;
    unsigned int j = 0;
    unsigned int t = 0;
    char* string_buffer = NULL;
    uint32_t string_buffer_len = 0;
    MINIFLAC_RESULT res = MINIFLAC_OK;

    fprintf(stdout,"[cuesheet]\n");

    /* the catalog string is always a 128-byte string, the
     * miniflac_cuesheet_catalogue_length function is for convenience, so
     * we can treat it the same as variable-length strings */
    if(miniflac_cuesheet_catalog_length(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp32) != MINIFLAC_OK) abort();
    mem->len -= used;
    mem->pos += used;

    if(temp32 > string_buffer_len) {
        string_buffer = (char*)realloc(string_buffer,temp32 + 1);
        if(string_buffer == NULL) abort();
        string_buffer_len = temp32;
    }

    if(miniflac_cuesheet_catalog_string(decoder,&mem->buffer[mem->pos],mem->len,&used,string_buffer,string_buffer_len+1,&temp32) != MINIFLAC_OK) abort();
    mem->len -= used;
    mem->pos += used;
    string_buffer[temp32] = '\0';
    fprintf(stdout,"  media catalog number: ");
    for(t=0;t<temp32;t++) {
        if(string_buffer[t] == '\0') break;
        fprintf(stdout,"%c",string_buffer[t]);
    }
    if(t == 0) {
        fprintf(stdout,"(empty)");
    }
    fprintf(stdout,"\n");

    if(miniflac_cuesheet_leadin(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp64) != MINIFLAC_OK) abort();
    mem->len -= used;
    mem->pos += used;
    fprintf(stdout,"  leadin: %llu\n",(unsigned long long)temp64);

    if(miniflac_cuesheet_cd_flag(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp8) != MINIFLAC_OK) abort();
    mem->len -= used;
    mem->pos += used;
    fprintf(stdout,"  cd_flag: %u\n",temp8);

    if(miniflac_cuesheet_tracks(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp8) != MINIFLAC_OK) abort();
    mem->len -= used;
    mem->pos += used;
    fprintf(stdout,"  tracks: %u\n",temp8);

    i = 0;
    while( (res =miniflac_cuesheet_track_offset(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp64)) == MINIFLAC_OK) {
        mem->len -= used;
        mem->pos += used;
        fprintf(stdout,"  [track %u]\n",++i);
        fprintf(stdout,"    offset: %llu\n",(unsigned long long)temp64);

        if(miniflac_cuesheet_track_number(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp8) != MINIFLAC_OK) abort();
        mem->len -= used;
        mem->pos += used;
        fprintf(stdout,"    number: %u\n",temp8);

        if(miniflac_cuesheet_track_isrc_length(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp32) != MINIFLAC_OK) abort();
        mem->len -= used;
        mem->pos += used;

        if(temp32 > string_buffer_len) {
            string_buffer = (char*)realloc(string_buffer,temp32 + 1);
            if(string_buffer == NULL) abort();
            string_buffer_len = temp32;
        }
        if(miniflac_cuesheet_track_isrc_string(decoder,&mem->buffer[mem->pos],mem->len,&used,string_buffer,string_buffer_len+1,&temp32) != MINIFLAC_OK) abort();
        mem->len -= used;
        mem->pos += used;
        string_buffer[temp32] = '\0';
        fprintf(stdout,"    isrc: ");
        for(t=0;t<temp32;t++) {
            if(string_buffer[t] == '\0') break;
            fprintf(stdout,"%c",string_buffer[t]);
        }
        if(t == 0) {
            fprintf(stdout,"(empty)");
        }
        fprintf(stdout,"\n");

        if(miniflac_cuesheet_track_audio_flag(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp8) != MINIFLAC_OK) abort();
        mem->len -= used;
        mem->pos += used;
        fprintf(stdout,"    type: %u\n",temp8);

        if(miniflac_cuesheet_track_preemph_flag(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp8) != MINIFLAC_OK) abort();
        mem->len -= used;
        mem->pos += used;
        fprintf(stdout,"    preemph: %u\n",temp8);

        if(miniflac_cuesheet_track_indexpoints(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp8) != MINIFLAC_OK) abort();
        mem->len -= used;
        mem->pos += used;
        fprintf(stdout,"    indexpoints: %u\n",temp8);

        j = 0;
        while( (res = miniflac_cuesheet_index_point_offset(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp64)) == MINIFLAC_OK) {
            mem->len -= used;
            mem->pos += used;

            fprintf(stdout,"    [index point %u]\n",++j);
            fprintf(stdout,"      offset: %llu\n",(unsigned long long)temp64);

            if(miniflac_cuesheet_index_point_number(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp8) != MINIFLAC_OK) abort();
            mem->len -= used;
            mem->pos += used;
            fprintf(stdout,"      number: %u\n",temp8);
        }
        mem->len -= used;
        mem->pos += used;
        if(res != MINIFLAC_METADATA_END) abort();
    }
    mem->len -= used;
    mem->pos += used;
    if(res != MINIFLAC_METADATA_END) abort();

    free(string_buffer);
    fflush(stdout);
}

static void
dump_seektable(miniflac_t* decoder, membuffer_t* mem) {
    uint32_t used = 0;
    uint16_t temp16 = 0;
    uint64_t temp64 = 0;
    unsigned int i = 0;
    MINIFLAC_RESULT res = MINIFLAC_OK;

    fprintf(stdout,"[seektable]\n");
    while( (res = miniflac_seektable_sample_number(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp64)) == MINIFLAC_OK) {
        mem->len -= used;
        mem->pos += used;

        fprintf(stdout,"  [seekpoint %u]\n",++i);
        fprintf(stdout,"    sample number: %llu\n",(unsigned long long)temp64);

        if(miniflac_seektable_sample_offset(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp64) != MINIFLAC_OK) abort();
        mem->len -= used;
        mem->pos += used;
        fprintf(stdout,"    sample offset: %llu\n",(unsigned long long)temp64);

        if(miniflac_seektable_samples(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp16) != MINIFLAC_OK) abort();
        mem->len -= used;
        mem->pos += used;
        fprintf(stdout,"    samples: %u\n",temp16);
    }
    mem->len -= used;
    mem->pos += used;
    fflush(stdout);
    if(res != MINIFLAC_METADATA_END) abort();
}

static void
dump_application(miniflac_t* decoder, membuffer_t* mem) {
    uint32_t used;
    uint32_t temp32;

    fprintf(stdout,"[application]\n");
    if(miniflac_application_id(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp32) != MINIFLAC_OK) abort();
    mem->len -= used;
    mem->pos += used;
    fprintf(stdout,"  id: 0x%08x\n",temp32);

    if(miniflac_application_length(decoder,&mem->buffer[mem->pos],mem->len,&used,&temp32) != MINIFLAC_OK) abort();
    mem->len -= used;
    mem->pos += used;
    fprintf(stdout,"  length: %u bytes\n",temp32);
    fflush(stdout);

    /* another example of skipping the decode */
}

static MINIFLAC_RESULT _miniflac_init(miniflac_t* decoder, membuffer_t *mem)
{
    miniflac_init(decoder,MINIFLAC_CONTAINER_UNKNOWN);
    int fileSize = mem->len;
    mem->pos = 0;
    uint32_t used = 0;
    MINIFLAC_RESULT res = MINIFLAC_ERROR;
    while(mem->pos < fileSize)
    {
        res = miniflac_sync(decoder,&mem->buffer[mem->pos],mem->len,&used);
        mem->len -= used;
        mem->pos += used;
        if(res == MINIFLAC_OK)
        {
            /* work our way through the metadata frames */
            if(decoder->state == MINIFLAC_METADATA) {
                if(decoder->metadata.header.type == MINIFLAC_METADATA_STREAMINFO) {
                    res = dump_streaminfo(decoder,mem, NULL, NULL, NULL, NULL);

                    //if(res != MINIFLAC_OK)
                        //break;
                }
                else if(decoder->metadata.header.type == MINIFLAC_METADATA_VORBIS_COMMENT) {
                    dump_vorbis_comment(decoder,mem);
                }
                else if(decoder->metadata.header.type == MINIFLAC_METADATA_PICTURE) {
                    dump_picture(decoder,mem);
                }
                else if(decoder->metadata.header.type == MINIFLAC_METADATA_CUESHEET) {
                    dump_cuesheet(decoder,mem);
                }
                else if(decoder->metadata.header.type == MINIFLAC_METADATA_SEEKTABLE) {
                    dump_seektable(decoder,mem);
                }
                else if(decoder->metadata.header.type == MINIFLAC_METADATA_APPLICATION) {
                    dump_application(decoder,mem);
                }

                if((res = miniflac_sync(decoder,&mem->buffer[mem->pos],mem->len,&used)) != MINIFLAC_OK)
                    break;
                mem->len -= used;
                mem->pos += used;
            }
            else
                break;
        }
        else
        {
            //printf("xxx %d\n", res);
            break;
        }
    }
    if ( res < 0 ) {
        common->Warning( "_miniflac_init() failed: %s\n", my_miniflac_strerror(res) );
        mem->pos = 0;
        mem->len = fileSize;
        return res;
    }
    return MINIFLAC_OK;
}

static MINIFLAC_RESULT _miniflac_seek(miniflac_t* decoder, membuffer_t *mem, int fileSize, int frames)
{
    assert(mem == NULL);

    uint32_t used = 0;
    uint32_t len;
    uint32_t sampSize;
    miniflac_init(decoder,MINIFLAC_CONTAINER_UNKNOWN);
    int lastLen = mem->len;
    int lastPos = mem->pos;
    mem->len = fileSize;
    mem->pos = 0;
    MINIFLAC_RESULT res = _miniflac_init(decoder, mem);
    if(res != MINIFLAC_OK)
        return res;

    //miniflac_reset()
    size_t headers_len = decoder->bytes_read_flac - decoder->frame.header.size;
    mem->len = fileSize-(headers_len + frames);
    mem->pos = headers_len + frames;

    miniflac_reset(decoder, MINIFLAC_FRAME);

    res = miniflac_sync(decoder,&mem->buffer[mem->pos],mem->len,&used);
    printf("III %zd | %zd | %zd | %d -> %d\n", headers_len, decoder->bytes_read_flac, decoder->frame.header.size, frames,res);
    if(res == MINIFLAC_OK)
    {
        mem->len -= used;
        mem->pos += used;
    }
    else
    {
        mem->len = lastLen;
        mem->pos = lastPos;
    }

    return res;
}
#endif

/*
====================
idWaveFile::OpenFLAC
====================
*/
int idWaveFile::OpenFLAC(const char *strFileName, waveformatex_t *pwfx)
{
#if 0
    memset( pwfx, 0, sizeof( waveformatex_t ) );
    if ( idSoundSystemLocal::s_realTimeDecoding.GetBool() ) {
        common->Warning("OpenFLAC: FLAC not support realtime decoding");
        mhmmio = NULL;
        return -1;
    }
#endif

    mhmmio = fileSystem->OpenFileRead( strFileName );
    if ( !mhmmio ) {
        return -1;
    }

    Sys_EnterCriticalSection( CRITICAL_SECTION_ONE );

    int fileSize = mhmmio->Length();
    byte* buf = (byte*)Mem_Alloc( fileSize );

    mhmmio->Read( buf, fileSize );

    uint32_t used = 0;
    membuffer_t mem;
    mem.buffer = buf;
    mem.len = fileSize;
    mem.pos = 0;

    miniflac_t* decoder = (miniflac_t*)malloc(miniflac_size());
    miniflac_init(decoder,MINIFLAC_CONTAINER_UNKNOWN);
    MINIFLAC_RESULT res;
    uint32_t sample_rate;
    uint8_t channels;
    uint8_t bps;
    uint64_t total_samples;
    bool found = false;

    while(mem.pos < fileSize)
    {
        res = miniflac_sync(decoder,&mem.buffer[mem.pos],mem.len,&used);
        mem.len -= used;
        mem.pos += used;

        /* work our way through the metadata frames */
        if(res == MINIFLAC_OK)
        {
            /* work our way through the metadata frames */
            if(decoder->state == MINIFLAC_METADATA) {
/*
            printf("metadata block: type: %u, is_last: %u, length: %u\n",
                   decoder->metadata.header.type_raw,
                   decoder->metadata.header.is_last,
                   decoder->metadata.header.length);
*/
                if(decoder->metadata.header.type == MINIFLAC_METADATA_STREAMINFO) {
                    res = dump_streaminfo(decoder,&mem, &sample_rate, &channels, &bps, &total_samples);
                    found = true;

                    //if(res != MINIFLAC_OK)
                        break;
                }
            }
            else
                break;
        }
        else
            break;
    }

    bool fail = false;
    if( res < 0 || !found ) {
        common->Warning( "Opening FLAC file '%s' with miniflac failed: %s\n", strFileName, my_miniflac_strerror(res) );
        fail = true;
    } else if( channels > 2 ) {
        common->Warning( "Opening FLAC file '%s' with miniflac failed: unsupport channels > 2\n", strFileName );
        fail = true;
    } else if( bps > 16 ) {
        common->Warning( "Opening FLAC file '%s' with miniflac failed: unsupport bps > 16\n", strFileName );
        fail = true;
    }

    if( fail ) {
        Mem_Free( buf );
        free(decoder);
        Sys_LeaveCriticalSection( CRITICAL_SECTION_ONE );
        fileSystem->CloseFile( mhmmio );
        mhmmio = NULL;
        return -1;
    }

    mfileTime = mhmmio->Timestamp();
    int numSamples = (int)total_samples;

    if( total_samples == 0 ) {
        common->Warning( "Couldn't get sound length of '%s' with miniflac: %d\n", strFileName, numSamples );
        // TODO:  return -1 etc?
    }

    mpwfx.Format.nSamplesPerSec = sample_rate;
    mpwfx.Format.nChannels = channels;
    mpwfx.Format.wBitsPerSample = sizeof(short) * 8; // bps
    mdwSize = numSamples * channels;	// pcm samples * num channels
    mbIsReadingFromMemory = false;
    //printf("flac %d | %d | %d | %u\n=====================\n", numSamples, mdwSize, channels, sample_rate);

    if ( idSoundSystemLocal::s_realTimeDecoding.GetBool() ) {

        fileSystem->CloseFile( mhmmio );
        mhmmio = NULL;
        Mem_Free( buf );
        free(decoder);

        mpwfx.Format.wFormatTag = WAVE_FORMAT_TAG_FLAC;
        mhmmio = fileSystem->OpenFileRead( strFileName );
        mMemSize = mhmmio->Length();

    } else {

		flac = decoder;
        flacMem = (membuffer_t *)Mem_Alloc(sizeof(membuffer_t));
        *(membuffer_t *)flacMem = mem;

        mpwfx.Format.wFormatTag = WAVE_FORMAT_TAG_PCM;
        mMemSize = mdwSize * sizeof( short );
    }

    memcpy( pwfx, &mpwfx, sizeof( waveformatex_t ) );

    Sys_LeaveCriticalSection( CRITICAL_SECTION_ONE );

    isFlac = true;

    return 0;
}

/*
====================
idWaveFile::ReadFLAC
 total: bytes
 len: bytes
====================
*/
int idWaveFile::ReadFLAC(byte *pBuffer, int dwSizeToRead, int *pdwSizeRead)
{
    int total = dwSizeToRead;
    byte *bufferPtr = pBuffer;
    miniflac_t *decoder = (miniflac_t *) flac;
    membuffer_t *mem = (membuffer_t *) flacMem;
    uint32_t used;
    MINIFLAC_RESULT res;
    uint8_t shift;
    uint32_t sampSize;
    packer pack;
    uint32_t len;
    //static int aaa = 0;
    //static int iii = 0;

    do {
        int32_t fbuffer1[MINIFLAC_READ_BUFFER_LENGTH];
        int32_t fbuffer2[MINIFLAC_READ_BUFFER_LENGTH];
        int32_t *samples[] = {
                &fbuffer1[0], &fbuffer2[0]
        };

        res = miniflac_decode(decoder,&mem->buffer[mem->pos],mem->len,&used,samples);
        if(res != MINIFLAC_OK)
        {
            common->Warning( "idWaveFile::ReadFLAC() miniflac_decode() %d shorts failed: %s\n", MINIFLAC_READ_BUFFER_LENGTH, my_miniflac_strerror(res) );
            return -1;
        }
        mem->len -= used;
        mem->pos += used;

        if(decoder->frame.header.bps <= 8) {
            sampSize = 1; pack = uint8_packer; shift = 8 - decoder->frame.header.bps;
        } else { // else if(decoder->frame.header.bps <= 16)
            sampSize = 2; pack = int16_packer; shift = 16 - decoder->frame.header.bps;
        }

        len = sampSize * decoder->frame.header.channels * decoder->frame.header.block_size;
        //aaa += len;
        //printf("%d: %d | %d | %d | %d\n", iii++, aaa, total, len, total - len);

        pack(bufferPtr,samples,decoder->frame.header.channels,decoder->frame.header.block_size,shift);

        // FFF 13428113 | 26856226 | 2 | 44100 = 53712452 | 1604 | 1604 | 0
        // OOO 13428113 | 26856226 | 2 | 44100 = 53712452 | 1348 | 1348 | 0
        // MMM 13428113 | 26856226 | 2 | 44100 = 53712452 | 1604 | 1604 | 0
        // xh_1: 6714057 | 13428113
        // MMM 13428113 | 13428113 | 1 | 44100 = 26856226 | 802 | 802 | 0
        // OOO 13428113 | 13428113 | 1 | 44100 = 26856226 | 162 | 162 | 0
        // FFF 13428113 | 13428113 | 1 | 44100 = 26856226 | 802 | 802 | 0
		// ret is samples of all channels
        bufferPtr += len;
        total -= len;

        /* sync up to the next frame boundary */
        res = miniflac_sync(decoder,&mem->buffer[mem->pos],mem->len,&used);
        mem->len -= used;
        mem->pos += used;
        if(res != MINIFLAC_OK) break;
    } while( total > 0 );

    dwSizeToRead = (byte *)bufferPtr - pBuffer;

    if ( pdwSizeRead != NULL ) {
        *pdwSizeRead = dwSizeToRead;
    }

    return dwSizeToRead;
}

/*
====================
idWaveFile::CloseFLAC
====================
*/
int idWaveFile::CloseFLAC(void)
{
    if ( flac != NULL ) {
        Sys_EnterCriticalSection( CRITICAL_SECTION_ONE );
		free(flac);
        Sys_LeaveCriticalSection( CRITICAL_SECTION_ONE );
        fileSystem->CloseFile( mhmmio );
        mhmmio = NULL;
        flac = NULL;
        Mem_Free( flacMem );
        flacMem = NULL;
        return 0;
    }
    return -1;
}


/*
====================
idSampleDecoderLocal::DecodeFLAC
====================
*/
int idSampleDecoderLocal::DecodeFLAC(idSoundSample *sample, int sampleOffset44k, int sampleCount44k, float *dest)
{
#if 0
    common->Warning("DecodeFLAC: FLAC not support realtime decoding on idSoundSample '%s'", sample->name.c_str());
    failed = true;
    return 0;
#else
	int readSamples, totalSamples;

	int shift = 22050 / sample->objectInfo.nSamplesPerSec;
	int sampleOffset = sampleOffset44k >> shift;
	int sampleCount = sampleCount44k >> shift;

	// open FLAC file if not yet opened
	if (lastSample == NULL) {
		// make sure there is enough space for another decoder
		if (decoderMemoryAllocator.GetFreeBlockMemory() < MIN_OGGVORBIS_MEMORY) {
			return 0;
		}

		if (sample->nonCacheData == NULL) {
            common->Warning( "Called idSampleDecoderLocal::DecodeFLAC() on idSoundSample '%s' without nonCacheData\n", sample->name.c_str() );
			failed = true;
			return 0;
		}

        assert(flac == NULL);
        assert(flacMem == NULL);

        miniflac_t* decoder = (miniflac_t*)malloc(miniflac_size());
        miniflac_init(decoder,MINIFLAC_CONTAINER_UNKNOWN);
        uint32_t used = 0;
        membuffer_t mem;
        mem.buffer = sample->nonCacheData;
        mem.len = sample->objectMemSize;
        mem.pos = 0;
        MINIFLAC_RESULT res = _miniflac_init(decoder, &mem);
        if ( res != MINIFLAC_OK ) {
            common->Warning( "idSampleDecoderLocal::DecodeFLAC() _miniflac_init() for %s failed: %s\n",
                             sample->name.c_str(), my_miniflac_strerror(res) );
            free(decoder);
            failed = true;
            return 0;
        }

		lastFormat = WAVE_FORMAT_TAG_FLAC;
		lastSample = sample;
		flac = decoder;
        flacMem = (membuffer_t *)Mem_Alloc(sizeof(membuffer_t));
		*flacMem = mem;
	}

	// seek to the right offset if necessary
	if (sampleOffset != lastSampleOffset) {
        if ( _miniflac_seek( flac, flacMem, sample->objectMemSize, sampleOffset / sample->objectInfo.nChannels ) != MINIFLAC_OK ) {
            int offset = sampleOffset / sample->objectInfo.nChannels;
            common->Warning( "idSampleDecoderLocal::DecodeFLAC() flac unsupport seek(%d) for %s\n",
                             offset, sample->name.c_str() );
            failed = true;
            return 0;
        }
	}

	lastSampleOffset = sampleOffset;

	// decode FLAC samples
	totalSamples = sampleCount;
	readSamples = 0;
    uint32_t used = 0;
    uint32_t len = 0;
    uint32_t sampSize;
    packer pack;

    printf("CCC %d | %d | %d\n", flacMem->len, flacMem->pos, sample->objectMemSize);
	do {
        short samplesBuf[2 * MINIFLAC_READ_BUFFER_LENGTH];
        int32_t fbuffer1[MINIFLAC_READ_BUFFER_LENGTH];
        int32_t fbuffer2[MINIFLAC_READ_BUFFER_LENGTH];
        int32_t *samples[] = {
                &fbuffer1[0], &fbuffer2[0]
        };
        int ret = miniflac_decode(flac,&flacMem->buffer[flacMem->pos],flacMem->len,&used,samples);
        if ( ret != MINIFLAC_OK ) {
            common->Warning( "idSampleDecoderLocal::DecodeFLAC() miniflac_decode() %d (%d) samples\n  for %s failed: %s\n",
                             MINIFLAC_READ_BUFFER_LENGTH, totalSamples, sample->name.c_str(), my_miniflac_strerror( ret ) );
            failed = true;
            return 0;
        }
        flacMem->len -= used;
        flacMem->pos += used;

        if(flac->frame.header.bps <= 8) {
            sampSize = 1; pack = uint8_packer; shift = 8 - flac->frame.header.bps;
        } else { // else if(decoder->frame.header.bps <= 16)
            sampSize = 2; pack = int16_packer; shift = 16 - flac->frame.header.bps;
        }

        len = sampSize * flac->frame.header.channels * flac->frame.header.block_size;

        pack((uint8_t *)samplesBuf,samples,flac->frame.header.channels,flac->frame.header.block_size,shift);

		SIMDProcessor->UpSamplePCMTo44kHz(dest + (readSamples << shift), samplesBuf, ret, sample->objectInfo.nSamplesPerSec, sample->objectInfo.nChannels);

		// ret is samples of all channels
        len /= flac->frame.header.block_size;
        len /= sizeof(short);
		readSamples += len;
		totalSamples -= len;
        //printf("%d | %d | %d | %d | %d\n", len, readSamples, totalSamples, flacMem->len, flacMem->pos);

        /* sync up to the next frame boundary */
        ret = miniflac_sync(flac,&flacMem->buffer[flacMem->pos],flacMem->len,&used);
        flacMem->len -= used;
        flacMem->pos += used;
        if(ret != MINIFLAC_OK) break;
	} while (totalSamples > 0);

	lastSampleOffset += readSamples;

	return (readSamples << shift);
#endif
}

