#ifdef __ANDROID__
#ifdef __aarch64__
#define IEEE_8087
#define Arith_Kind_ASL 1
#define Long int
#define Intcast (int)(long)
#define Double_Align
#define X64_bit_pointers
#else
#define IEEE_8087
#define Arith_Kind_ASL 1
#define Double_Align
#endif
#endif
