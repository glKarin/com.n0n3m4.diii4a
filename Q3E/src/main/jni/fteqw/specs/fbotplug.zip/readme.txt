option a:
	1: rename zip to fbotplug.pk3 (WITHOUT the extension, you silly windows users)
	2: copy to your gamedir, or the fte subdir, eg c:\quake\id1
option b:
	1: extract to your gamedir (preserve paths - stoopid winzip)
	(use quake/fte if you want all mods)
	2: 
3: NQ: set addon0 fbotnq
3: QW: set addon0 fbotqw
4: start a map
5: use impulse 101 to spawn a bot


notes:
waypoints are provided for maps dm1-dm6
uses DP_SV_BOTCLIENT to avoid having to replace half the stuffcmd/centerprint/etc functions, also resolves issues with frikbot's QW support, but not properly ported, might bug after 23 bots.
fte's built in qc compiler will automatically compile it, end-users can directly use the source without regard to compilers. if you make changes you can recompile in fte with 'compile fbotnq'. Or you can compile it explicitly yourself (clear out the home dir if you used the internal compiler), which would obviously require option b.
requires fteqcc
uses fteqcc's 'newstyle' progs.src - first non-comment is a # - which results in a dependance upon #include and #pragma instead.
plugin requires keywords that require TARGET=FTE. this is done via pragmas, and will not load in other engines (wouldn't work anyway).
