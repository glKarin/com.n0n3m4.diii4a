char *version_string = "GNU Bison version 1.24\n";
